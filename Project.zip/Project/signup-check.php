<!DOCTYPE html>
<html lang-="en">
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="resto.png">
        <meta name="viewport" content="widthg=device-width, initial-scale=1.0">
        <title>Resto.</title>
        <script src="https://kit.fontawesome.com/a3c8f3c756.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="header.css">
        <link rel="stylesheet" href="foodmenu.css">
        <link rel="stylesheet" href="steps1.css"
    </head>
    <body>
        <section class="header">

            <a href="homepage.html " class="logo"><i class="fa-solid fa-utensils"></i> Resto. </a>
         
            <nav class="navbar">
               <a href="homepage.html">home</a>
               <a href="gallery.html">gallery</a>
               <a href="menu.html">menu</a>
               <a href="order.html">order</a>
               <a href="#blogs">blogs</a>
               <a href="about.html">about</a>
               <a href="login.php">login</a>
            </nav>        
         </section>
<?php
$a9=$_POST['name'];
$b9=$_POST['pass'];
$sql1="INSERT into users values('$a9','$b9','0')";
$result1= mysqli_query(mysqli_connect("localhost","root","","test_db1"), $sql1);
echo "<center><h1>Your Account Has Been successfully created.</h1></center>";
echo "<center><b><a href='login.php'class='btn'>Go To SignIN page</a></b></center>";
?></body></html>