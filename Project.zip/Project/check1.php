<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['username']) && isset($_POST['psw'])) {
$uname=$_POST['username'];
$pass=$_POST['psw'];
//	function validate($data){
//  	   $data = trim($data);
//   	   $data = stripslashes($data);
//	   $data = htmlspecialchars($data);
//	   return $data;
//	}

//	$uname = validate($_POST['username']);
	$_SESSION['user_name']= $uname;
//	$pass = validate($_POST['psw']);
//	echo $uname;
//	echo $pass;
	if (empty($uname)) {
		header("Location: login.php?error=User Name is required");
	    exit();
	}else if(empty($pass)){
        header("Location: login.php?error=Password is required");
	    exit();
	}else{
		// hashing the password
       // $pass = md5($pass);

       ECHO "HI";
		$sql = 'SELECT * FROM users WHERE user_name="$uname" AND password="$pass"';
		
		$result = mysqli_query(mysqli_connect("localhost","root","","test_db1"), $sql);

//if (mysqli_num_rows($result) >= 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['user_name'] == $uname && $row['password'] == $pass) {
            	$_SESSION['user_name'] = $row['user_name'];
            	$_SESSION['id'] = $row['id'];
				echo "Successfully Logged in";
            	header("Location: welcome.php");
		        exit();
			echo $row['user_name'];
			echo $row['password'];
            }else{
				header("Location: login.php?error=User name or Password does not exist.Please register");
		        exit();
			}
		//}
	}
	
}else{
	header("Location: index.php");
	exit();
}?>