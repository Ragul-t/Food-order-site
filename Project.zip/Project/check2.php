<!DOCTYPE html>
<html lang-="en">
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="resto.png">
        <meta name="viewport" content="widthg=device-width, initial-scale=1.0">
        <title>Resto.</title>
        <script src="https://kit.fontawesome.com/a3c8f3c756.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="header.css">
        <link rel="stylesheet" href="foodmenu.css">
        <link rel="stylesheet" href="steps1.css"
    </head>
    <body>
        <section class="header">

            <a href="homepage.html " class="logo"><i class="fa-solid fa-utensils"></i> Resto. </a>
         
            <nav class="navbar">
               <a href="homepage.html">home</a>
               <a href="gallery.html">gallery</a>
               <a href="menu.html">menu</a>
               <a href="order.html">order</a>
               <a href="#blogs">blogs</a>
               <a href="about.html">about</a>
               <a href="login.php">login</a>
            </nav>        
         </section>
<?php
$a1=mysqli_connect("localhost","root","","test_db1");
if (isset($_POST['username']) && isset($_POST['psw'])) {
	$uname=$_POST['username'];
	$pass=$_POST['psw'];
	if (empty($uname)) {
		header("Location: login.php?error=UserName is required");
	    exit();
	}else if(empty($pass)){
        header("Location: login.php?error=Password is required");
	    exit();
	}
	else{
	$sql2 = "SELECT * FROM users where user_name='$uname'";
	$result2 = mysqli_query($a1,$sql2);
	$row=mysqli_fetch_assoc($result2);
	if($row){
	if($row['user_name']==$uname && $row['password']==$pass){
echo "<center><h1>Your are successfully logged in</h1></center>";
echo "<center><b><a href='homepage1.html' class='btn'>Go To HomePage</a></b></center>";}
	else{
	header("Location: login.php?error=UserName and Password doesn't match");
	    exit();
}
}}}?>