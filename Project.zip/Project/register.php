<!DOCTYPE html>
<html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" href="register.css">
            <title>Resto.</title>
        </head>
        <body>
            <div class="container">
                <div class="heading">Registration</div><br>
                <?php if (isset($_GET['error'])) { ?>
     		<p class="error" style="color:red;"><b><?php echo $_GET['error']; ?></b></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success" style="color:green;"><b><?php echo $_GET['success']; ?><b></p>
          <?php } ?> 
                <form action="signup-check.php" method="post" id="fm">
                    <div class="card-details">
                        <div class="card-box">
                            <span class="details">UserName</span>
                            <input type="text" name="name" id='name' placeholder="Enter your name" required>
                        </div>
                        <div class="card-box">
                            <span class="details">Phone Number</span>
                            <input type="phone" name="phone" id='phone'placeholder="Phone Number" maxlength="10" minlength="10">
                        </div>
                        <div class="card-box">
                            <span class="details">Password</span>
                            <input type="password" name="pass" id="psw" placeholder="Enter your password">
                        </div>
                        <div class="card-box">
                            <span class="details">Confirm Password</span>
                            <input type="password" name="cpass" id="cnfrmpsw"  placeholder="Confirm password"><br>
                           <b> <p id="passcpass"></p></b>
                        </div>
                    </div>
                        <div class="gender">
                            <span class="gendername">Gender</span>
                            <div class="category">
                                <input type="radio" name="gender">  Male
                                <input type="radio" name="gender">  Female
                                <input type="radio" name="gender">  Prefer not to say
                            </div>
                        </div>
                        <div class="button">
                            <input type="button" value="Register" onclick='myfun()'>
                        </div>
                </form><br>
                <div class="login">Already Registered?
                    <a href="login.php">Login here</a>
                </div>
            </div>
<script> function myfun(){ 
var a4=document.getElementById('name').value;
var a2=document.getElementById('phone').value;
var a1=document.getElementById('psw').value;
var a5=document.getElementById('cnfrmpsw').value;
if(a4=='' || a4==null){
window.alert('Enter Name');}
else if((Number.isInteger(parseInt(a2)))==false || a2.length!=10)
{
window.alert('Mobile Number should contain only numbers and should have 10 numbers');}
else if(a1.length<8)
{
window.alert("Password should contain eight characters");
}
else if(a1!=a5)
{
window.alert("Password and Confirm password doesn't match!");
}
else{
document.getElementById('fm').submit();
}
}
</script>
       </body>
</html>