<!DOCTYPE html>
<html lang-="en">
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="resto.png">
        <meta name="viewport" content="widthg=device-width, initial-scale=1.0">
        <title>Resto.</title>
        <script src="https://kit.fontawesome.com/a3c8f3c756.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="header.css">
        <link rel="stylesheet" href="foodmenu.css">
        <link rel="stylesheet" href="steps1.css">
	<style>tr th{
	font-weight:bold;
    }
table{box-shadow:2px 2px 20px grey;}
tr th, tr td{
	font-size:25px;
	
	padding:5px;
}
th{
    border: 5px solid #cc9452;
}
td{
	border: 5px solid #cc9452;
}
.c1{
	background:#eeeee4;
	text-align:center;
}
.c2{
	background:#eeeee4;
	text-align:center;
}
.c3{
	background:#eeeee4;
	text-align:center;
}
.c4{
	background:#eeeee4;
	text-align:center;
}
.c5{
background:#f0bc62;
}	
.c6{padding-top:50px;}
</style>
    </head>
    <body>
        <section class="header">

            <a href="homepage.html " class="logo"><i class="fa-solid fa-utensils"></i> Resto. </a>
         
            <nav class="navbar">
               <a href="homepage.html">home</a>
               <a href="gallery.html">gallery</a>
               <a href="menu.html">menu</a>
               <a href="order.html">order</a>
               <a href="#blogs">blogs</a>
               <a href="about.html">about</a>
               <a href="login.php">login</a>
            </nav>        
         </section>
<?php
$a=$_POST['fname'];
$b=$_POST['food_name'];
$c=$_POST['adr'];
$d=$_POST['num'];
$e=$_POST['qt'];
$f=100*$e;
$sql1="INSERT into orders values('0','$a','$b','$c','$d','$e')";
$result=mysqli_query(mysqli_connect("localhost","root","","test_db1"),$sql1);
$sql2="SELECT * FROM orders WHERE Customer='$a'";
$result1 = mysqli_query(mysqli_connect("localhost","root","","test_db1"),$sql2);
$rw=mysqli_fetch_assoc($result1);
?>
<center><div style='padding-top:100px'>        
<table>
  <tr>
    <th class="c5">Name</th>
    <th class="c5">Food-Quantity</th>
    <th class="c5">Phone</th>
    <th class="c5">Address</th>
	<th class='c5'>Cost</th>
  </tr> 
<?php
echo "<tr><td class='c1'>".$rw['Customer']."</td>";
echo "<td class='c2'>".$rw['Food']."-".$e."</td>";
echo "<td class='c3'>".$rw['Phone']."</td>";
echo "<td class='c4'>".$rw['Address']."</td>";
echo "<td class='c4'>".$f."</td></tr></table></div><center>";
echo "<center><h1 class='c6'>Your Order has been Accepted.Thank You For Choosing our Service</h1></center>";
echo "<center><b><a href='#'class='btn'>Proceed to pay-Rs.$f</a></b></center>";
echo $rw['Quantity'];
?></body></html>