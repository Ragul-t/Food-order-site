<!DOCTYPE html>
<html>
    <html leng="en">
        <head>
            <meta charset="UTF-8">
            <link rel="icon" href="resto.png">
            <title>Resto.</title>
            <link rel="stylesheet" href="login.css">
        </head>
        <body>
            <section>
                <div class="form-container">
                    <h1>Login Form</h1>
                    <form action="check2.php" method="post">
                    <div class="control">
                    <?php if (isset($_GET['error'])) { ?>
                            <p class="error" style="color:red;"><?php echo $_GET['error']; ?></p>
                        <?php } ?>   
                        </div>
                        
                        <div class="control">
                            <br><label for ="username">Name</label>
                            <input placeholder="Username" type="text" name="username" id="username">
                        </div>
                        <div class="control">
                            <label for="psw">Password</label>
                            <input placeholder="Password"type="password" name="psw" id="psw">
                        </div>
                        <span><input type="checkbox"> Remember me</span>
                        <div class="control">
                            <input type="submit" value="Login" >
                        </div>
                    </form>
                    <div class="link">
                        <a href="#">Forgot Password?</a>
                    </div><br>
					  <center><div >Don't have an account?
						  <a href='register.php' style='text-decoration:none'>Signup</a></div></center>
                    
                </div>
            </section>
        </body>
</html>